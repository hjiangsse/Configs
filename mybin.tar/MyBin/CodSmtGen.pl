use warnings;
use strict;
use Getopt::Std;

sub help
{
    print "Usage: perl CodSmtGen.pl -s SIR_NUM -d SRC_DIR -p ATP -o OUT_FILE\n";
    print "  -s  SIR_NUM:  SIR号, 如32894\n";
    print "  -d  SRC_DIR:  本地源代码目录, 请在这个目录下存放所有要提交的代码文件\n";
    print "  -p      ATP:  平台ATP or ITP\n";
    print "  -o OUT_FILE:  输出的代码提交列表文件\n";
}

#generate some messages about the sir, all input by the user
#the messages are the follows:
#1. SIR Title
#2. SIR Action
#3. SIR Owner
sub GenSirMsg
{
    print "Please input the Title of the SIR(e.g. A050200_EIDown): \n";
    my $sir_title = <>;
    chomp($sir_title);
    $sir_title = uc($sir_title);

    print "Please input the Action of the SIR(e.g. Add): \n";
    my $sir_action = <>;
    chomp($sir_action);
    $sir_action = uc($sir_action);

    print "Please input the Owner of the SIR(e.g. HJIANG): \n";
    my $sir_owner = <>;
    chomp($sir_owner);
    $sir_owner = uc($sir_owner);

    return ($sir_title, $sir_action, $sir_owner);
}

#Get all valid files under a directory
#.COM .c(C) .h(H) .pl(PL) .dwr(DWR)
sub GetDirFiles
{
    my $src_dir = shift;
    my @valid_files = ();

    opendir(my $dir, $src_dir)
        or die "Can't open $src_dir, $!";

    my @all_files = readdir($dir);

    foreach (@all_files)
    {
        my @name_segs = split('\.', $_);

        if(defined($name_segs[1]) &&
           $name_segs[1] =~ /com|c|h|dwr|pl/i)
        {
            push @valid_files, $_;
        }
    }

    return \@valid_files;
}

sub GetFileSufix
{
    my $file_name = shift;
    my @file_segs = split('\.', $file_name);
    return $file_segs[1];
}

#Process a single file
#e.g TEST.C
#--> TEST.C SRC A00001_TEST ADD 12345 HJIANG U4$:[HJIANG.DEV.SRC.12345]TEST.C
sub ProcSingleFile
{
    my $file_name = shift;
    my $sir_title = shift;
    my $sir_action = shift;
    my $sir_num = shift;
    my $sir_owner = shift;
    my $sir_plat = shift;

    my $plat = "DEV";
    if($sir_plat eq "ITP")
    {
        $plat = "WATER";
    }

    my $file_sufix = GetFileSufix($file_name);
    my $line = "";

    if($file_sufix eq "c" or $file_sufix eq "C")
    {
        $line = sprintf("%-30s\t%-10s\t%-20s\t%-10s\t%-8s\t%-10s\t%-s",
                           uc($file_name),
                           "SRC",
                           uc($sir_title),
                           uc($sir_action),
                           uc($sir_num),
                           uc($sir_owner),
                           "U4\$:[".uc($sir_owner).".$plat.SRC.".$sir_num."]".uc($file_name));
    }
    elsif($file_sufix eq "dwr" or $file_sufix eq "DWR")
    {
        $line = sprintf("%-30s\t%-10s\t%-20s\t%-10s\t%-8s\t%-10s\t%-s",
                           uc($file_name),
                           "MIG_DOC",
                           uc($sir_title),
                           uc($sir_action),
                           uc($sir_num),
                           uc($sir_owner),
                           "U4\$:[".uc($sir_owner).".$plat.MIG_DOC.".$sir_num."]".uc($file_name));
    }
    elsif($file_sufix eq "com" or $file_sufix eq "COM" or
       $file_sufix eq "pl" or $file_sufix eq "PL")
    {
        $line = sprintf("%-30s\t%-10s\t%-20s\t%-10s\t%-8s\t%-10s\t%-s",
                           uc($file_name),
                           "DCL",
                           uc($sir_title),
                           uc($sir_action),
                           uc($sir_num),
                           uc($sir_owner),
                           "U4\$:[".uc($sir_owner).".$plat.DCL.".$sir_num."]".uc($file_name));
    }
    elsif($file_sufix eq "h" or $file_sufix eq "H")
    {
        printf("%s is in PRJ or DIC? \n", $file_name);
        my $prj_or_dic = <>;
        chomp($prj_or_dic);
        $prj_or_dic = uc($prj_or_dic);

        print $prj_or_dic,"\n";

        if($prj_or_dic eq "PRJ")
        {
           $line = sprintf("%-30s\t%-10s\t%-20s\t%-10s\t%-8s\t%-10s\t%-s",
                               uc($file_name),
                               "PRJ_LIB",
                               uc($sir_title),
                               uc($sir_action),
                               uc($sir_num),
                               uc($sir_owner),
                               "U4\$:[".uc($sir_owner).".$plat.PRJ_LIB.".$sir_num."]".uc($file_name));
        }

        if($prj_or_dic eq "DIC")
        {
            $line = sprintf("%-30s\t%-10s\t%-20s\t%-10s\t%-8s\t%-10s\t%-s",
                               uc($file_name),
                               "DICDATA",
                               uc($sir_title),
                               uc($sir_action),
                               uc($sir_num),
                               uc($sir_owner),
                               "U4\$:[".uc($sir_owner).".$plat.DICDATA.".$sir_num."]".uc($file_name));
        }
    }
    else
    {
        printf("%s is a invalid file!\n", $file_name);
    }

    return $line;
}

sub GenSubmitFile
{
    my $files_ref = shift;
    my $out_file_path = shift;

    my $title = shift;
    my $action = shift;
    my $num = shift;
    my $owner = shift;
    my $plat = shift;


    open(my $out_hndl, ">", $out_file_path)
        or die "Can't open $out_file_path, $!\n";

    foreach (@{$files_ref})
    {
        my $cur_line = ProcSingleFile($_,
                                      $title,
                                      $action,
                                      $num,
                                      $owner,
                                      $plat);

        print $out_hndl $cur_line,"\n";
        #print $cur_line,"\n";
    }

    close($out_hndl);
}

sub main
{
    #process options
    my %options = ();
    getopts("hs:d:p:o:", \%options);

    if (defined $options{h})
    {
        help();
        return 0;
    }

    if ( defined $options{s} and
         defined $options{d} and
         defined $options{p} and
         defined $options{o})
    {
        my ($title, $action, $owner) = GenSirMsg();
        my $srcs_ref = GetDirFiles($options{d});

        GenSubmitFile($srcs_ref,
                      $options{o},
                      $title,
                      $action,
                      $options{s},
                      $owner,
                      $options{p});
    }
	else
    {
		print "[Error] Parameter Not Enough!\n";
		return 1;
	}

    return 0;
}

exit main();
