#!/bin/bash


function show_help () {
    echo "Usage: procdir -d . -p aaa -o d -s .com"
    echo " -d: the directory you want to select or change."
    echo " -p: the regex pattern used to select or change."
    echo " -o: s(select files match this pattern) or d(delete lines match such pattern)"
    echo " -s: file suffix(.com stands for select or delete lines of all *.com files)"
}

function working_horse () {
    echo "Select or Change in directory: $1"
    echo "Pattern: $2"
    echo "Operation: $3"
    echo "File Suffix: $4"

    cmd="find $1 -name \*$4 -type f -exec grep -Hn '$2' {} \;"
    echo $cmd
    }

OPTIND=1

while getopts "h?d:p:o:s:" opt; do
    case "$opt" in
        h|\?)
            show_help
            exit 0
            ;;
        d)
            dir=$OPTARG
            ;;
        p)
            pattern=$OPTARG
            ;;
        o)
            oprt=$OPTARG
            ;;
        s)
            suff=$OPTARG
            ;;
    esac
done

if [ -n "$dir" ] && [ -n "$pattern" ] && [ -n "$oprt" ] && [ -n "$suff" ]; then
    working_horse $dir $pattern $oprt $suff
else
    echo "argument error!"
fi
