use warnings;
use strict;
use Getopt::Std;

sub help
{
    print "Usage: perl IncreGen.pl -o oldcfgs_path -n newcfgs_path -d dest_path \n";
    print "     -o: 上一版本配置存放目录(目录中必需含有xxx_node_full.csv,xxx_file_full.csv,xxx_confirm_full.csv)\n";
    print "     -n: 新版本配置存放目录(目录中必需含有xxx_node_full.csv,xxx_file_full.csv,xxx_confirm_full.csv)\n";
    print "     -d: 增量文件存放目录(未指定目录的话，就存放在本地)\n";
}

sub get_clean_path
{
    my $raw_path = shift;
    my $last_char = substr($raw_path, -1);
    if($last_char eq '/' or
       $last_char eq '\\')
    {
        return substr($raw_path,0,-1);
    }
    return $raw_path;
}

#输入:全量配置文件名
#输出:增量配置文件名
sub get_incre_filename
{
    my $full_name = shift;
    $full_name =~ s/full/incre/g;
    return $full_name;
}

#检查目录下有名称为*_node_full.csv,
#*_file_full.csv,*_confirm_full.csv的文件
sub path_check
{
    my $dst_path = shift;

    my $node_flag = 0;
    my $file_flag = 0;
    my $confirm_flag = 0;

    my @file_path = ();

    opendir(my $dir, $dst_path);
    my @files = readdir($dir);

    foreach (@files)
    {
        if($_ =~ /_node_full.csv$/)
        {
            $node_flag = $node_flag + 1;
            $file_path[0] = $_;
        }

        if($_ =~ /_file_full.csv$/)
        {
            $file_flag = $file_flag + 1;
            $file_path[1] = $_;
        }

        if($_ =~ /_confirm_full.csv/)
        {
            $confirm_flag = $confirm_flag + 1;
            $file_path[2] = $_;
        }
    }

    if( $node_flag != 1 or
        $file_flag != 1 or
        $confirm_flag != 1 )
    {
        print $dst_path," Config file not enough or too much!\n";
        return -1;
    }

    close $dir;
    return \@file_path;
}

#获取文件配置增量文件
sub get_file_incre
{
    my $old_file_cfg = shift;
    my $new_file_cfg = shift;
    my $incre_cfg = shift;

    my %old_file_hash = ();

    #get old file config hash,
    #key is file name
    open(my $old_hndl, "<", $old_file_cfg)
        or die "Can not open old file config. $!\n";
    open(my $new_hndl, "<", $new_file_cfg)
        or die "Can not open new file config. $!\n";
    open(my $incre_hndl, ">", $incre_cfg)
        or die "Can not open incre file config. $!\n";

    while(my $line = <$old_hndl>)
    {
        chomp($line);
        my @line_segs = split(",",$line);
        $old_file_hash{$line_segs[0]} = $line;
    }

    while(my $line = <$new_hndl>)
    {
        chomp($line);
        my @line_segs = split(",",$line);

        if( $line =~ /FileID/i or
            $line =~ /NodeID/i or
            $line =~ /fieldid/i )
        {
            print $incre_hndl "Mode,",$line,"\n";
        }
        else
        {
            if(not exists $old_file_hash{$line_segs[0]})
            {
                print $incre_hndl "A,",$line,"\n";
            }
            else
            {
                if(not $line eq $old_file_hash{$line_segs[0]})
                {
                    print $incre_hndl "M,",$line,"\n";
                }
            }
        }
    }

    close $old_hndl;
    close $new_hndl;
    close $incre_hndl;
}

sub main
{
    #process options
    my %options = ();
    getopts("ho:n:d:", \%options);

    if (defined $options{h})
    {
        help();
        return 0;
    }

    if ( defined $options{o} and
         defined $options{n} )
    {
        my $old_chk = path_check($options{o});
        if($old_chk == -1)
        {
            return 1;
        }

        my $new_chk = path_check($options{n});
        if($new_chk == -1)
        {
            return 1;
        }

        for(my $i = 0; $i < scalar(@$new_chk); $i = $i + 1)
        {
            my $abs_old_path = get_clean_path($options{o})."/".$old_chk->[$i];
            my $abs_new_path = get_clean_path($options{n})."/".$new_chk->[$i];
            my $incre_name = get_incre_filename($old_chk->[$i]);
            get_file_incre($abs_old_path, $abs_new_path, $incre_name);

            #将生成的增量文件拷贝到指定的目录
            system("mv $incre_name $options{d}");
        }
    }
	else
    {
		print "[Error] Parameter Not Enough!\n";
		return 1;
	}




    return 0;
}

exit main();
