#!/usr/bin/perl
#
#   Usage:��OpenVMS/HP-UX ��̨����ȡ��ǰ̨
#   Usage: perl get_source.pl P1 P2 P3 P4
#    Para: P1 ���ش���·�� WindowsĿ¼
#          P2 Զ��������� 0:HP-UX 1:OpenVMS MTP ����:OpenVMS ATP
#          P3 �û��������Ȱ��û�ATTACH�������˻�������ֱ��ʹ�ü����˻�
#          P4 ����
#          P5 source level, Ĭ��Ϊjlevel��ȡֵΪP D������ΪĬ�ϡ�
#   perl C:\SRC\get_source.pl C:\SRC\ATP_SRC\A040007 2 liaoqiu liaoqiu D (��Ҫ�� def_level DEV)
#   perl C:\SRC\get_source.pl C:\SRC\ITP_SRC\I010300 2 INTEG33 ngtscfg D (��Ҫ�� def_level water)
#   perl C:\SRC\get_source.pl C:\SRC\ngts_src\C260005 1 liaoqiu 111111 

use Net::FTP;
my $FTP;

$HPUX_host   = "172.19.100.51" ;
#HSD001
$OpenVMS_mtp = "172.23.1.55" ;
#HSDV03
$OpenVMS_atp = "172.23.1.101" ;


###############################################################################
sub main
{
    &get_parameter();

    &Connect;
    $FTP->ascii;
    #$FTP->binary;

    if ( $des_host eq $HPUX_host )
    {
        &get_HPUX_file();
    }
    else
    {
        &get_OpenVMS_file();
    }

    &Disconnect;
}

###############################################################################

sub get_parameter
{
    $local_path = $ARGV[0] ;
    if ($local_path !~ /\\$/)
    {
        $local_path .= "\\";
    }
    mkdir($local_path) unless -e $local_path;

    if ($ARGV[1] == 0 )
    {
        $des_host = $HPUX_host
    }
    elsif ($ARGV[1] == 1 )
    {
        $des_host = $OpenVMS_mtp
    }
    else
    {
        $des_host = $OpenVMS_atp
    }

    if ($ARGV[2])
    {
        $user = $ARGV[2];
    }
    else
    {
        print "user:";
        $user = <stdin>;
    }

    if ($ARGV[3])
    {
        $pwd = $ARGV[3];
    }
    else
    {
        print "password:";
        $pwd  = <stdin>;
    }
    
    if ($ARGV[4])
    {
        $sourceLevel = $ARGV[4];
    }
    else
    {
        $sourceLevel = "J";
    }

}

###############################################################################

sub trim
{
    my $string = shift;
    $string =~ s/^\s+//; $string =~ s/\s+$//;
    return $string;
}

###############################################################################

sub Connect
{
    $FTP = Net::FTP->new ("$des_host", Debug => 0) or die "Unable to connect to host $@";
    $FTP->login($user,$pwd) or die "Failed to login $!";
}

###############################################################################

sub Disconnect
{
    $FTP->quit;
}

###############################################################################

sub get_OpenVMS_file
{
    print $sourceLevel."\n";
    if ($sourceLevel eq "P")
    {
        #P LEVEL
        &ProcessList( "PSRC");
        &ProcessList( "PDCL");
        &ProcessList( "PPRJ");
        &ProcessList( "PDIC");
        &ProcessList( "PFDL");
        &ProcessList( "PXENV");
        &ProcessList( "POPT" );
        &ProcessList( "PMIG_DOC" );
    }
    elsif ($sourceLevel eq "D")
    {
        #D LEVEL
        &ProcessList( "DSRC");
        &ProcessList( "DDCL");
        &ProcessList( "PRJ");
        &ProcessList( "DICDATA");
        &ProcessList( "DFDL");
        &ProcessList( "DXENV");
        &ProcessList( "DOPT" );
        &ProcessList( "DMIG_DOC" );
    }
    else
    {
        #J LEVEL
        &ProcessList( "JSRC");
        &ProcessList( "JDCL");
        &ProcessList( "JPRJ");
        &ProcessList( "JDIC");
        &ProcessList( "JFDL");
        &ProcessList( "JXENV");
        &ProcessList( "JOPT" );
        &ProcessList( "JMIG_DOC" );
    }
}

###############################################################################

sub ProcessList
{
    my $downCount = 0;
    $dir = $_[0];
    print $dir."\n";
    $path = "$local_path$dir\\";
    mkdir($path) unless -e $path;

    %fileCopyOrNot=();

    @filelist = $FTP->ls ("$dir:*.*;");

    foreach $file (@filelist)
    {
        @name= $file =~ m/\S+\](\S+)\;\d+/;
        $fullpath = $path . $name[0];

        if ($name[0] !~ /[\S]+\.[\w]/)
        {
            print "file name not correct $file -> $name[0]\n";
            next;
        }
        if ($fileCopyOrNot{$name[0]} == 1)
        {
            next;
        }

        print "Copy $file to $fullpath...\n";

        if ($FTP->get ($file, $fullpath, 0))
        {
            $downCount++;
            $fileCopyOrNot{$name[0]} = 1;
        }
        else
        {
           print "get $file $!\n";
        }

    }
    $allcount = @filelist;
    print "file count is $allcount,$downCount succeed!\n";
}

###############################################################################

sub get_HPUX_file()
{
    #����������
    #&ProcessUnixList( "\/home\/zqsysop\/zqdps\/bin");
    #&ProcessUnixList( "\/home\/zqsysop\/zqdps\/ttcsrc");
    #&ProcessUnixList( "\/home\/zqsysop\/zqdps\/src");
    #&ProcessUnixList( "\/home\/zqsysop\/zqdps\/srctrans");
    #&ProcessUnixList( "\/home\/zqsysop\/zqdps\/etc");
    #&ProcessUnixList( "\/home\/zqsysop\/sye");
    #ʵʱ����
    #&ProcessUnixList( "\/sse\/bin");
    #&ProcessUnixList( "\/sse\/src");
    #&ProcessUnixList( "\/sse\/data\/remotein.20111202");
    #&ProcessUnixList( "\/sse\/data\/interface");
    &ProcessUnixList( "\/sse\/tranbank");

}

###############################################################################

sub ProcessUnixList
{
    my $downCount = 0;

    @dir_temp = split("\/",$_[0]);
    $win_dir = pop(@dir_temp);
    $win_dir = "$local_path$win_dir\\";
    mkdir($win_dir) unless -e $win_dir;

    $dir = $_[0];
    @filelist = $FTP->ls ("$dir\/*");

    foreach $file (sort(@filelist))
    {
        if ($file !~ /[A-Za-z0-9]$/)
        {
            #print "file name not correct $file -> $name[0]\n";
            next;
        }

        @file_temp = split("\/",$file);
        $win_file = pop(@file_temp);
        $fullpath = $win_dir . $win_file;

        print "Copy $file to $fullpath\n";

        if ( $FTP->get ($file, $fullpath, 0))
        {
            $downCount++;
        }
        else
        {
            print "get $file $!\n";
        }
    }
    $allcount = @filelist;
    print "file count is $allcount,$downCount succeed!\n";
}

###############################################################################
&main;
